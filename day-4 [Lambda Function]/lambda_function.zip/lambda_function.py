import json
import boto3
s3 = boto3.client('s3')
def lambda_handler(event, context):
    
    # Source S3 bucket and file details
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    source_key = event['Records'][0]['s3']['object']['key']
    response=str(source_bucket)+str(source_key)
    print(response)
    # Destination S3 bucket and file details
    destination_bucket = 'my-unique-destination-bucket-9849'
    destination_key = source_key  # Keeping the same key for destination (can modify if needed)

    response = s3.copy_object(CopySource={'Bucket': source_bucket, 'Key': source_key},Bucket=destination_bucket,Key=destination_key)
    
    # Print response
    print(response)
